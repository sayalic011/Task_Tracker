export const JWT_SECRET = "TASK_APP_SECRET";
export const JWT_EXPIRES_IN = "1h";
